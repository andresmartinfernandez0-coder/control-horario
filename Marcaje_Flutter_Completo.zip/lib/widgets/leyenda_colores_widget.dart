import 'package:flutter/material.dart';

class LeyendaColoresWidget extends StatelessWidget {
  const LeyendaColoresWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.info_outline),
      onPressed: () {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Significado de colores'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Row(children: [Icon(Icons.circle, color: Colors.green), SizedBox(width: 10), Text('Jornada completa')]),
                Row(children: [Icon(Icons.circle, color: Colors.yellow), SizedBox(width: 10), Text('Jornada incompleta')]),
                Row(children: [Icon(Icons.circle, color: Colors.blue), SizedBox(width: 10), Text('Horas extra')]),
                Row(children: [Icon(Icons.circle, color: Colors.orange), SizedBox(width: 10), Text('Fichaje rectificado')]),
                Row(children: [Icon(Icons.circle, color: Colors.red), SizedBox(width: 10), Text('Fichaje eliminado')]),
                Row(children: [Icon(Icons.circle, color: Colors.purple), SizedBox(width: 10), Text('Fichaje con foto')]),
                Row(children: [Icon(Icons.circle, color: Colors.grey), SizedBox(width: 10), Text('Sin fichaje')]),
              ],
            ),
            actions: [
              TextButton(onPressed: () { Navigator.pop(context); }, child: const Text('Cerrar'))
            ],
          ),
        );
      },
    );
  }
}