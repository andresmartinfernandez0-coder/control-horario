import 'package:flutter/material.dart';
import 'screens/fichaje_screen.dart';
import 'screens/calendario_screen.dart';
import 'screens/historial_screen.dart';
import 'screens/exportar_screen.dart';
import 'screens/ajustes_screen.dart';
import 'widgets/bottom_navbar.dart';

void main() {
  runApp(const MarcajeApp());
}

class MarcajeApp extends StatelessWidget {
  const MarcajeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Marcaje',
      theme: ThemeData(primarySwatch: Colors.green),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    const FichajeScreen(),
    const CalendarioScreen(),
    const HistorialScreen(),
    const ExportarScreen(),
    const AjustesScreen(),
  ];

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
      ),
    );
  }
}