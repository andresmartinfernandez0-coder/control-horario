import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AjustesScreen extends StatefulWidget {
  const AjustesScreen({super.key});

  @override
  State<AjustesScreen> createState() => _AjustesScreenState();
}

class _AjustesScreenState extends State<AjustesScreen> {
  final TextEditingController _nombreController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _cargarNombre();
  }

  Future<void> _cargarNombre() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _nombreController.text = prefs.getString('nombre') ?? '';
  }

  Future<void> _guardarNombre() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('nombre', _nombreController.text);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Nombre guardado correctamente')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _nombreController,
              decoration: const InputDecoration(labelText: 'Nombre del trabajador'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _guardarNombre,
              child: const Text('Guardar nombre'),
            ),
          ],
        ),
      ),
    );
  }
}