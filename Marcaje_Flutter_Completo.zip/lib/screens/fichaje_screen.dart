import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FichajeScreen extends StatefulWidget {
  const FichajeScreen({super.key});

  @override
  State<FichajeScreen> createState() => _FichajeScreenState();
}

class _FichajeScreenState extends State<FichajeScreen> {
  String nombreTrabajador = 'Sin nombre';
  @override
  void initState() {
    super.initState();
    _cargarNombre();
  }

  Future<void> _cargarNombre() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      nombreTrabajador = prefs.getString('nombre') ?? 'Sin nombre';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fichaje')),
      body: Center(child: Text('Pantalla de fichaje para \$nombreTrabajador')),
    );
  }
}